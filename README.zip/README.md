 <h1> Balaco social </h1>
 <p>Landing Page criada para a Banda Balanço social <br>
 para anúnciar o trabalho deles e facilitar a prospecção de clientes.</p>
 <hr>
 <h2>Forms</h2>
 <p>O formulario envia as informações para o email cadastrado e depois direciana o clinte direto para conversa do whatsapp da Banda</p>
<hr>
link do site : https://balanco-social.netlify.app/
 
